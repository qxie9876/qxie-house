export PATH=/home/qxie/softwares/mgltools_1.5.6/bin/:$PATH
export PATH=/home/qxie/softwares/autodock_4_2_6/:$PATH
export PATH=/home/qxie/softwares/autodock_vina_1_1_2/bin/:$PATH


